# -*- coding: utf-8 -*-
"""
Figuras del sitio y del artículo, generadas desde Resultados/*.csv.

Salida en SVG: escala sin pixelarse, el texto sigue siendo texto (buscable y seleccionable) y
pesa menos que un PNG a 300 dpi. Las mismas funciones guardan PNG a 300 dpi para el manuscrito.

Criterios de diseño aplicados en todas:
  * un solo eje por figura (nunca dos escalas verticales),
  * color por entidad y no por posición: una opción conserva su color aunque cambie de orden,
  * el n siempre visible — con paneles de 7 a 10 personas, un porcentaje sin n engaña,
  * rejilla y ejes recesivos, etiquetas directas en vez de leyendas cuando caben.
"""
import os
import math
import itertools
import collections

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch
import networkx as nx

import datos

SALIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")

# Paleta divergente validada para daltonismo (ΔE CVD 8.4, visión normal 18.1).
AZUL, GRIS, ROJO = "#2a78d6", "#8a8880", "#e34948"
TINTA, TINTA2, TINTA3 = "#0b0b0b", "#52514e", "#84827c"
LINEA, PANEL = "#e5e3dd", "#ffffff"
# Escala categórica para opciones: orden fijo, nunca ciclada.
CATEG = ["#2a78d6", "#e34948", "#8a8880", "#1b9e77", "#8b5cf6", "#d97706", "#0891b2"]
# Para la cuadrícula, sin el gris neutro: ahí el gris claro significa "sin clasificar" y
# tener además un gris de opción hace que se confundan.
CATEG_GRID = ["#2a78d6", "#e34948", "#1b9e77", "#d97706", "#8b5cf6", "#0891b2", "#be185d"]

plt.rcParams.update({
    "figure.facecolor": PANEL, "axes.facecolor": PANEL,
    "savefig.facecolor": PANEL, "savefig.bbox": "tight", "savefig.dpi": 300,
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Helvetica", "Arial", "sans-serif"],
    "font.size": 9, "axes.titlesize": 10.5, "axes.labelsize": 9,
    "axes.edgecolor": LINEA, "axes.linewidth": .8, "axes.labelcolor": TINTA2,
    "xtick.color": TINTA3, "ytick.color": TINTA3,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
    "svg.fonttype": "none",          # el texto queda como texto en el SVG
    "axes.spines.top": False, "axes.spines.right": False,
})


def _guardar(fig, nombre, png=False):
    os.makedirs(SALIDA, exist_ok=True)
    ruta = os.path.join(SALIDA, nombre + ".svg")
    fig.savefig(ruta, format="svg", transparent=False)
    if png:
        fig.savefig(os.path.join(SALIDA, nombre + ".png"))
    plt.close(fig)
    return ruta


def inline(ruta):
    """Devuelve el SVG listo para incrustar: sin cabecera XML y con ancho fluido."""
    with open(ruta, encoding="utf-8") as f:
        s = f.read()
    s = s[s.index("<svg"):]
    s = s.replace('width="', 'data-w="', 1).replace('height="', 'data-h="', 1)
    return s.replace("<svg ", '<svg style="width:100%;height:auto" ', 1)


def _paleta_opciones(opciones):
    return {o: CATEG[i % len(CATEG)] for i, o in enumerate(opciones)}


def _corta(s, n=26):
    s = str(s)
    return s if len(s) <= n else s[:n - 1] + "…"


# ── 1. Flujo de opiniones entre rondas (aluvial) ──────────────────────────────

def _cinta(ax, x0, x1, y0a, y0b, y1a, y1b, color, alpha):
    """Cinta entre dos bandas, con bordes en curva de Bézier."""
    dx = (x1 - x0) * .5
    verts = [(x0, y0a), (x0 + dx, y0a), (x1 - dx, y1a), (x1, y1a),
             (x1, y1b), (x1 - dx, y1b), (x0 + dx, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4,
             Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), facecolor=color, edgecolor="none",
                           alpha=alpha, zorder=1))


def fig_flujo(qids, png=False, nombre="fig_flujo"):
    """
    Aluvial: cómo se reparten los panelistas entre opciones en cada ronda y quién se mueve.
    Cada cinta es un grupo de panelistas; el color es su opción DE ORIGEN, así que se puede
    seguir a dónde fue cada bloque inicial. Las cintas de quien no se mueve van más tenues.
    """
    d = datos.clasificadas()
    qids = [q for q in qids if q in set(d.qid)]
    n = len(qids)
    fig, axes = plt.subplots(1, n, figsize=(6.8 * n, 3.9))
    axes = np.atleast_1d(axes)

    for ax, q in zip(axes, qids):
        g = d[d.qid == q]
        rondas = sorted(g.Round.unique())
        piv = g.pivot_table(index="Panelist", columns="Round",
                            values="selected_option", aggfunc="first")
        piv = piv.reindex(columns=rondas)
        opciones = sorted({v for c in rondas for v in piv[c].dropna().unique()})
        pal = _paleta_opciones(opciones)

        # posición vertical de cada banda por ronda
        bandas, GAP = {}, .06
        for r in rondas:
            cuenta = piv[r].value_counts()
            total = cuenta.sum()
            if not total:
                continue
            y = 0.0
            for o in opciones:
                c = cuenta.get(o, 0)
                if not c:
                    continue
                h = c / total * (1 - GAP * max(0, len(cuenta) - 1))
                bandas[(r, o)] = (y, y + h, c)
                y += h + GAP

        SEP = 2.6
        for i, (r0, r1) in enumerate(zip(rondas, rondas[1:])):
            sub = piv[[r0, r1]].dropna()
            flujos = collections.Counter(zip(sub[r0], sub[r1]))
            desde = collections.defaultdict(float)
            hacia = collections.defaultdict(float)
            for (o0, o1), c in sorted(flujos.items(), key=lambda kv: (opciones.index(kv[0][0]),
                                                                     opciones.index(kv[0][1]))):
                if (r0, o0) not in bandas or (r1, o1) not in bandas:
                    continue
                b0, b1 = bandas[(r0, o0)], bandas[(r1, o1)]
                h0 = (b0[1] - b0[0]) * c / b0[2]
                h1 = (b1[1] - b1[0]) * c / b1[2]
                y0 = b0[0] + desde[o0]
                y1 = b1[0] + hacia[o1]
                _cinta(ax, i * SEP + .16, (i + 1) * SEP - .16, y0, y0 + h0, y1, y1 + h1,
                       pal[o0], .60 if o0 != o1 else .22)
                desde[o0] += h0
                hacia[o1] += h1

        for j, r in enumerate(rondas):
            for o in opciones:
                if (r, o) not in bandas:
                    continue
                y0, y1, c = bandas[(r, o)]
                ax.add_patch(plt.Rectangle((j * SEP - .16, y0), .32, y1 - y0,
                                           facecolor=pal[o], edgecolor=PANEL,
                                           linewidth=1.2, zorder=3))
                if y1 - y0 > .07:
                    ax.text(j * SEP, (y0 + y1) / 2, str(c), ha="center", va="center",
                            color="white", fontsize=8.5, fontweight="bold", zorder=4)
                if j == 0:
                    ax.text(-.32, (y0 + y1) / 2, _corta(o, 19), ha="right", va="center",
                            fontsize=8, color=TINTA2, zorder=4)
                elif j == len(rondas) - 1:
                    ax.text(j * SEP + .32, (y0 + y1) / 2, _corta(o, 19), ha="left", va="center",
                            fontsize=8, color=TINTA2, zorder=4)

        seguidos = piv.dropna(subset=[rondas[0], rondas[-1]])
        movidos = int((seguidos[rondas[0]] != seguidos[rondas[-1]]).sum())
        ax.set_title(f"{q} — {_corta(datos.texto(q), 44)}\n"
                     f"{movidos} de {len(seguidos)} cambian de opción entre la 1.ª y la 3.ª",
                     fontsize=9.5, color=TINTA, loc="left", pad=10)
        ax.set_xticks([j * SEP for j in range(len(rondas))])
        ax.set_xticklabels([f"Ronda {r}" for r in rondas])
        ax.set_xlim(-2.0, (len(rondas) - 1) * SEP + 2.0)
        ax.set_ylim(-.04, 1.06)
        ax.set_yticks([])
        for s in ("left", "bottom"):
            ax.spines[s].set_visible(False)
        ax.tick_params(length=0)

    fig.tight_layout()
    return _guardar(fig, nombre, png)


# ── 2. Cuadrícula panelista × pregunta ────────────────────────────────────────

def fig_cuadricula(panel, png=False):
    """
    Quién respondió qué, panelista por panelista y pregunta por pregunta, en cada ronda.

    Sustituye a la red de acuerdo entre panelistas que había antes. Aquella promediaba el
    acuerdo sobre todas las preguntas del panel, y con 4–6 preguntas categóricas cada arista
    descansaba en una mediana de 2 a 5 preguntas: un "acuerdo del 50 %" quería decir
    "coincidieron en 1 de 2", y el movimiento entre rondas era una persona cambiando una
    respuesta. Esto no promedia nada: se ve en QUÉ preguntas coincide cada grupo y en cuáles
    se parte, y las respuestas sin clasificar quedan como huecos en vez de desaparecer.

    Las filas se ordenan por parecido, así que los bloques de color contiguos son coaliciones.
    """
    d = datos.cargar_extraidas()
    g = d[(d.Panel == panel) & d.is_valid_response &
          d.question_type.isin(["nominal", "binary"])]
    rondas = sorted(g.Round.unique())
    preguntas = sorted(g.qid.unique(), key=lambda q: int(q.split("_Q")[1]))
    panelistas = sorted(g.Panelist.unique())

    # una paleta por pregunta: los colores sólo se comparan DENTRO de su columna
    pal = {}
    for q in preguntas:
        opts = sorted(x for x in g[g.qid == q].selected_option.dropna().unique()
                      if x != "Unclassified")
        pal[q] = {o: CATEG_GRID[i % len(CATEG_GRID)] for i, o in enumerate(opts)}

    # orden de filas por parecido, usando la última ronda como referencia
    ref = g[g.Round == rondas[-1]].pivot_table(index="Panelist", columns="qid",
                                               values="selected_option", aggfunc="first")
    ref = ref.reindex(index=panelistas, columns=preguntas)
    orden, restantes = [], list(panelistas)
    actual = restantes.pop(0)
    orden.append(actual)
    while restantes:
        def parecido(p_):
            amb = ref.loc[actual].notna() & ref.loc[p_].notna()
            return (ref.loc[actual][amb] == ref.loc[p_][amb]).sum() if amb.any() else -1
        actual = max(restantes, key=parecido)
        restantes.remove(actual)
        orden.append(actual)

    fig, axes = plt.subplots(1, len(rondas), figsize=(2.5 * len(rondas) + 1.6,
                                                      0.42 * len(orden) + 1.9),
                             sharey=True)
    axes = np.atleast_1d(axes)
    for ax, r in zip(axes, rondas):
        piv = g[g.Round == r].pivot_table(index="Panelist", columns="qid",
                                          values="selected_option", aggfunc="first")
        piv = piv.reindex(index=orden, columns=preguntas)
        for i, p_ in enumerate(orden):
            for j, q in enumerate(preguntas):
                v = piv.loc[p_, q]
                sin = pd.isna(v) or v == "Unclassified"
                ax.add_patch(plt.Rectangle(
                    (j + .06, i + .06), .88, .88,
                    facecolor="#f4f2ee" if sin else pal[q].get(v, GRIS),
                    edgecolor=PANEL, linewidth=1.4))
                if sin:
                    ax.plot([j + .35, j + .65], [i + .5, i + .5], color="#cfcbc3", lw=1.2)
        ax.set_xlim(0, len(preguntas)); ax.set_ylim(len(orden), 0)
        ax.set_xticks([j + .5 for j in range(len(preguntas))])
        ax.set_xticklabels([q.split("_")[1] for q in preguntas], fontsize=8)
        ax.set_yticks([i + .5 for i in range(len(orden))])
        ax.set_yticklabels([str(p_)[-2:] for p_ in orden], fontsize=8)
        ax.set_title(f"Ronda {r}", fontsize=9.5, color=TINTA, pad=8)
        for sp in ax.spines.values():
            sp.set_visible(False)
        ax.tick_params(length=0)
    axes[0].set_ylabel("Panelista", fontsize=8.5)
    fig.tight_layout()
    return _guardar(fig, f"fig_cuadricula_panel{panel}", png)


def leyenda_opciones(panel):
    """Leyenda HTML de la cuadrícula: qué color es qué opción, por pregunta."""
    d = datos.cargar_extraidas()
    g = d[(d.Panel == panel) & d.is_valid_response &
          d.question_type.isin(["nominal", "binary"])]
    preguntas = sorted(g.qid.unique(), key=lambda q: int(q.split("_Q")[1]))
    bloques = []
    for q in preguntas:
        opts = sorted(x for x in g[g.qid == q].selected_option.dropna().unique()
                      if x != "Unclassified")
        chips = "".join(
            f'<span class="chip"><i style="background:{CATEG_GRID[i % len(CATEG_GRID)]}"></i>'
            f'{_corta(o, 30)}</span>'
            for i, o in enumerate(opts))
        bloques.append(f'<div class="legq"><b>{q.split("_")[1]}</b> '
                       f'<span class="legqt">{_corta(datos.texto(q), 52)}</span>{chips}</div>')
    return '<div class="leygrid">' + "".join(bloques) + "</div>"


# ── 3. Trayectoria del consenso por pregunta ──────────────────────────────────

def fig_trayectoria(panel, png=False):
    """
    Cuánto se concentra el panel en su opción mayoritaria, ronda a ronda, para las preguntas
    de ESTE panel. Una línea por pregunta, con su id al final y coloreada según lo que le pasó.

    Es por panel a propósito: los cuatro paneles son estudios independientes —distintos
    panelistas, distintas preguntas— así que ponerlos en un eje común invitaría a comparaciones
    que los datos no sostienen.
    """
    c = pd.read_csv(datos._ruta("03_categorical_consensus.csv"))
    c["qid"] = [datos.qid(p_, q) for p_, q in zip(c.Panel, c.Question)]
    c = c[c.Panel == panel]
    conv = datos.convergencia().set_index("qid")["convergence"].to_dict()

    COL = {"Convergió": AZUL, "Se dispersó": ROJO,
           "Estable en acuerdo": "#1b9e77", "Estable sin acuerdo": GRIS}
    rondas = sorted(c.Round.unique())
    fig, ax = plt.subplots(figsize=(6.4, 3.9))

    finales = []
    for q, g in c.groupby("qid"):
        g = g.sort_values("Round")
        if g.modal_share.isna().all():
            continue
        col = COL.get(conv.get(q), GRIS)
        ax.plot(g.Round, g.modal_share * 100, color=col, lw=2.0, marker="o", markersize=5,
                markerfacecolor=PANEL, markeredgewidth=1.6, markeredgecolor=col, zorder=3)
        fin = g[g.Round == g.Round.max()]
        if not fin.empty and pd.notna(fin.modal_share.iloc[0]):
            finales.append((float(fin.modal_share.iloc[0] * 100), q))

    finales.sort()
    ultimo = -99
    for y, q in finales:
        yy = max(y, ultimo + 5.0)
        ax.annotate(q, (rondas[-1], yy), xytext=(8, 0), textcoords="offset points",
                    fontsize=8, color=TINTA2, va="center", annotation_clip=False)
        ultimo = yy

    for y, txt in ((75, "consenso fuerte"), (60, "mayoría clara")):
        ax.axhline(y, color=LINEA, lw=1, zorder=0)
        ax.text(rondas[0] - .04, y + 1.6, txt, fontsize=7.4, color=TINTA3, ha="left")

    ax.set_xticks(rondas)
    ax.set_xticklabels([f"Ronda {r}" for r in rondas])
    ax.set_xlim(rondas[0] - .06, rondas[-1] + .55)
    ax.set_ylim(20, 106)
    ax.set_ylabel("Panelistas en la opción mayoritaria (%)")
    ax.grid(axis="y", color=LINEA, lw=.6, zorder=0)
    ax.set_axisbelow(True)
    ax.spines["left"].set_visible(False)
    ax.tick_params(length=0)
    usadas = {conv.get(q) for _, q in finales}
    manijas = [plt.Line2D([], [], color=v, lw=2.2, label=k) for k, v in COL.items() if k in usadas]
    if manijas:
        ax.legend(handles=manijas, frameon=False, fontsize=8, ncol=2,
                  loc="lower center", bbox_to_anchor=(.5, -.26))
    fig.tight_layout()
    return _guardar(fig, f"fig_trayectoria_panel{panel}", png)


# NOTA: aquí vivía fig_movimiento, que ponía los cuatro paneles en un mismo eje
# (cuánto se mueve su gente frente a cuánto converge) y de ahí salía el hallazgo
# "moverse no es converger". Se retiró: los paneles son estudios independientes, con
# distintos panelistas y distintos conjuntos de preguntas, así que la variación entre
# ellos está confundida con la dificultad de sus preguntas. Con n=4 estudios no
# comparables, esa figura no sostenía ninguna conclusión.


def construir_todo(png=False):
    """Genera las figuras de cada panel por separado. No hay figuras entre paneles."""
    d = datos.clasificadas()
    salida = {}
    for panel in sorted(d.Panel.unique()):
        panel = int(panel)
        g = d[d.Panel == panel]
        mov = g.pivot_table(index=["qid", "Panelist"], columns="Round",
                            values="selected_option", aggfunc="first")
        ri, rf = min(mov.columns), max(mov.columns)
        mov = mov.dropna(subset=[ri, rf])
        top = (mov.assign(c=mov[ri] != mov[rf]).groupby("qid").c.sum()
               .sort_values(ascending=False))
        elegidas = [q for q in top.head(2).index if top[q] > 0]
        salida[panel] = {
            "cuadricula": fig_cuadricula(panel, png),
            "trayectoria": fig_trayectoria(panel, png),
            "flujos": [(q, fig_flujo([q], png, f"fig_flujo_{q}")) for q in elegidas],
        }
    return salida


if __name__ == "__main__":
    import sys
    r = construir_todo(png="--png" in sys.argv)
    print("Figuras generadas en", SALIDA + "/")
    for panel, v in r.items():
        print(f"  Panel {panel}: red + trayectoria + {len(v['flujos'])} aluvial(es)")
